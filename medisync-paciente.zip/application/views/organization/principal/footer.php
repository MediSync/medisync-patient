<!-- Bootstrap core JavaScript-->
<script src="assets/lib/admin-2/js/jquery.js"></script>
<script src="assets/lib/admin-2/js/bootstrap.bundle.js"></script>

<!-- Core plugin JavaScript-->
<script src="assets/lib/admin-2/js/jquery.easing.js"></script>

<!-- Custom scripts for all pages-->
<script src="assets/lib/admin-2/js/sb-admin-2.js"></script>
<script src="assets/lib/admin-2/js/Chart.js"></script>
<script src="assets/lib/admin-2/js/chart-area-demo.js"></script>
<script src="assets/lib/admin-2/js/dataTables.bootstrap4.min.js"></script>
<script src="assets/lib/admin-2/js/jquery.dataTables.js"></script>
<!-- <script src="assets/lib/admin-2/js/datatables-demo.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/3.1.2/rollups/md5.js"></script>
<script type="text/javascript" src="assets/lib/toastr-2.1.4-7/toastr.min.js"></script>
<script type="text/javascript" src="assets/lib/bootstrap-select-1.13.9/js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="assets/lib/bootstrap-datepicker-1.6.4/js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="assets/lib/bootstrap-datepicker-1.6.4/locales/bootstrap-datepicker.es.min.js"></script>
<script type="text/javascript" src="assets/lib/jquery.rut/jquery.rut.js"></script>
<script type="text/javascript" src="assets/js/main/organization.js"></script>
<script src="assets/lib/admin-2/js/custom.js"></script>


</body>

</html>
