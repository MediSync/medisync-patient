<div class="row" style="margin-top: 30px">
<!--
    <div class="offset-md-1">
        <div class="card" style="width: 18rem; ">
            <img src="assets/img/002.png" class="card-img-top" alt="...">
            <div class="card-body">
                <p class="card-text">Administre sus datos personales o actualice su contraseña.</p>
                <a href="#" id="gestion_pefil" class="btn btn-primary btn-block">Mi Perfil </a>
            </div>
        </div>
    </div>
    -->
    <div class="offset-md-1">
        <div class="card" style="width: 18rem; ">
            <img src="assets/img/001.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <p class="card-text">Consulte su historial clínico, junto con su evolución.</p>
                <a href="#" id="load_history_paciente" class="btn btn-primary btn-block">Mi Historial</a>
            </div>
        </div>
    </div>
</div>
